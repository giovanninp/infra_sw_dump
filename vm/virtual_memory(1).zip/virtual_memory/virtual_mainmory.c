#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "support.h"


int main(int argc, char const *argv[]){
	
	return 0;
}